@extends('base')

@section('contenido')

<h1>Landing Page</h1>
<a href="login">Login</a>
    
@stop