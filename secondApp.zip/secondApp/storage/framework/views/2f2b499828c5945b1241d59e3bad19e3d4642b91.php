<?php $__env->startSection('contenido'); ?>

<form action="home" method="post">
    <?php echo csrf_field(); ?>
    <label>Login: </label>
    <input type="text" name="nombre" required>
    <br>
    <label>Password: </label>
    <input type="password" name="clave" required>
    <br>
    <input type="submit">
</form>
<a href="forgotten">Forgotten Password</a>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/secondApp/resources/views/page2.blade.php ENDPATH**/ ?>