@extends('base')

@section('contenido')

<h1>User's Home</h1>

@stop