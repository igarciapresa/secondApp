<?php $__env->startSection('contenido'); ?>

<h1>Landing Page</h1>
<a href="login">Login</a>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/secondApp/resources/views/page1.blade.php ENDPATH**/ ?>