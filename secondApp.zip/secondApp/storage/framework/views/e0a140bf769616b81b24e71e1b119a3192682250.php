<?php $__env->startSection('contenido'); ?>

<form action="landingPage" method="post">
    <?php echo csrf_field(); ?>
    <label>Email: </label>
    <input type="email" name="nombre" required>
    <br>
    <input type="submit">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/secondApp/resources/views/page3.blade.php ENDPATH**/ ?>