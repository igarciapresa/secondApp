<?php $__env->startSection('contenido'); ?>

<h1>User's Home</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/secondApp/resources/views/page4.blade.php ENDPATH**/ ?>